import java.util.HashMap;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
	     
	     int totalprofit= 0;
	     // set up the total profit variable 
	     
		 System.out.println("Enter the number of months : ");
	     Scanner input = new Scanner(System.in);
	     int months = input.nextInt();
	     if(months < 0){
	    	 System.out.println("Invalid Input"); 
	    	 
	    	 System.exit(0);
	    	 //program will stop 
	    	 
	     }
	     System.out.println("Enter the profit of each month in shipment");
	     Scanner input2 = new Scanner(System.in);
	     while(months>0){
	    	 int value  = input2.nextInt();
	    	 
	    	 totalprofit = totalprofit +value ;
	    	 // add total profit  
	    	 
	    	 months--;
	    	 // when loop once it will minus one
	    	 
	     }
	     System.out.println("Total profit : " + totalprofit  );
	    
	    
	     }

}
