import java.util.HashMap;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
	     
	     int totalmonth =0;
		 System.out.println("Enter the total number of months");
	     Scanner input = new Scanner(System.in);
	     int months = input.nextInt();
	     System.out.println("Enter the profit amount of shipment in each month");
	     Scanner input2 = new Scanner(System.in);
	     while(months>0){
	    	 double value  = input2.nextDouble();
	    	 
	    	if(value >100000){
	    		totalmonth++;
	    	}
	    	 months--;
	     }
	     System.out.println("Profit value has exceeded Rs. 100000 for  " + totalmonth +" month(s)" );
	    
	    
	     }

}
