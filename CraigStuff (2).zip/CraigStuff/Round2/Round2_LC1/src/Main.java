import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
        System.out.println("Enter the number of shipments per month : ");
        Scanner input = new Scanner(System.in);   
        int shipmentNumber = input.nextInt();
        if(shipmentNumber <= 0){
        	System.out.println("Invalid Input ");
        }
        else if(shipmentNumber <= 20){
        	System.out.println("Not a valuable customer");
        }
        else if(shipmentNumber >20){
        	System.out.println("Valuable customer");
        }


	}

}
