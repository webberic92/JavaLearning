import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
        System.out.println(" Enter the invoice amount :");
        Scanner input = new Scanner(System.in);   
        int amount = input.nextInt();
       if(amount <=80000){
    	   System.out.println("Not Exceeded the credit limit!");
       }else {
    	   System.out.println(" Exceeded the limit!");
    	   int overamount =amount-80000;
    	   double overamountpercentage = (double)overamount /80000;
    	   System.out.println(overamount);
    	   System.out.println(overamountpercentage);
    	   if(overamountpercentage<=0.25){
    		   System.out.println("Penalty to be paid  " + (overamount + (overamount*0.1)));
    	   }else if(overamountpercentage<=0.50 && overamountpercentage > 0.25){
    		   System.out.println("Penalty to be paid  " + (overamount + (overamount*0.2)));
    	   }else if(overamountpercentage<=0.75 && overamountpercentage > 0.50){
    		   System.out.println("Penalty to be paid  " + (overamount + (overamount*0.3)));
    	   }else if(overamountpercentage>0.75){
    		   System.out.println("Penalty to be paid  " + (overamount + (overamount*0.4)));
    	   }
       }

	}

}
