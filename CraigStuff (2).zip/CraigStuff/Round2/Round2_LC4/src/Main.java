import java.util.HashMap;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
	     
	     
		 System.out.println("Enter the total number of countries : ");
	     Scanner input = new Scanner(System.in);
	     int Countries = input.nextInt();
	     System.out.println("Enter the total number of shipment per month :");
	     Scanner input2 = new Scanner(System.in);
	     int shipment = input2.nextInt();
	     if(Countries >150 && shipment >1500 ){
	    	 System.out.println("The company grade is : A");
	     }else  if(Countries>125 &&  shipment >1200){
	    	 System.out.println("The company grade is : B");
	     }else  if(Countries>100 &&  shipment >1000){
	    	 System.out.println("The company grade is : C");
	     }else  if(Countries>75 &&  shipment >700){
	    	 System.out.println("The company grade is : D");
	     }else  if((Countries <=75 && Countries>=0 )&& (shipment <=700 && shipment >=0)){
	    	 System.out.println("The company grade is : E");
	     }else  {
	    	 System.out.println("Invalid Input");
	     }
	  
	     // for the question, it has something wrong with the Grade E
	     // for example if you input 75 Countries and  701 for the shipment
	     // the output will be invalid input..
	    
	     }

}
