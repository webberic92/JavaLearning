import java.util.HashMap;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
	     HashMap<String,String> map = new HashMap<String,String>();
	     map.put("001", "Roadways");
	     map.put("100", "Airway");
	     map.put("010", "Waterways");
	     map.put("111", "All ways");
	     map.put("101", "Airway and Waterway");
	     map.put("011", "Roadways and Waterways");
	     map.put("110", "Roadways and Airway");
	     //Itterate everything in map. see it has 001.111,etccc
	     
	     
		 System.out.println("Enter the shipment code :");
	     Scanner input = new Scanner(System.in);
	     String shipmentCode = input.nextLine();
	     System.out.println(map.get(shipmentCode));
	     }

}
