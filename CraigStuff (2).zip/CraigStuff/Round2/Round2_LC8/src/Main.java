import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
        
		 System.out.println("Enter the range for shipment numbers :");
	     Scanner input = new Scanner(System.in);
	     int startingRange = input.nextInt();
	     Scanner input2 = new Scanner(System.in);
	     int endingRange  = input.nextInt();
	     if(startingRange <= endingRange ||startingRange < endingRange ){
	    	 if(startingRange%3 == 0){
		    	 System.out.println("Possible Shippment numbers...");

	    		 int countStartRange = startingRange;
	    		 while(countStartRange <= endingRange){
		    		 System.out.println(countStartRange);

	    			 countStartRange += 3;
	    		 }
	    	 }else {
	    		 System.out.println("Shippment Numbers Unavailable.");
	    	 }
	     }else {
	    	 System.out.println("not correct range");
	     }
	}

}
