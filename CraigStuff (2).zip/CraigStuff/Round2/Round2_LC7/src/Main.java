import java.util.HashMap;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
	     
	    boolean isPrimeNumber = true; 
	    // set if it is prime number true of false;
	    
	    
	    int sum =0;
		 System.out.println("Enter the shipment number :");
	     Scanner input = new Scanner(System.in);
	     int shipmentnumber = input.nextInt();
	    
	        while(shipmentnumber> 0)
	        {
	          int   temp = shipmentnumber % 10;
	            sum = sum + temp;
	            shipmentnumber = shipmentnumber / 10;
	        }
	        
	        //check the input and let each digit add together
	        
	         
	     if(sum>0){
	    	 int k = (int)Math.sqrt(sum);
	    	 for(int i =2;i<=k; i++){
	    		 if(sum %i ==0){
	    			 isPrimeNumber = false;
	    			 break;
	    		 }
	    	 }
	     }
	     
	     // check the sum  if it is prime number 
	     
	     if(isPrimeNumber){
	    	 System.out.println("Eligible for free shipping");
	     }else{
	    	 System.out.println("Not Eligible for free shipping");
	     }
	}
}
