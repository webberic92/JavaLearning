import java.util.HashMap;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
	     
	     
		 System.out.println("Enter the weight: ");
	     Scanner input = new Scanner(System.in);
	     int weight = input.nextInt();
	     System.out.println("Enter the distance");
	     Scanner input2 = new Scanner(System.in);
	     int distance = input2.nextInt();
	     if(weight <100 || distance <500 ){
	    	 System.out.println("Datex shipping offers discount");
	     }else {
	    	 System.out.println("Datex shipping offers no discount");
	     }
	    
	     }

}
