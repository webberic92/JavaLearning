import java.util.Scanner;

public class Main {

      public static void main(String[] args) {
            
            
            
            System.out.println("Enter the shipping cost of item 1");
            Scanner item1 = new Scanner(System.in);   
            int shippingitem1 = item1.nextInt();

            System.out.println("Enter the shipping cost of item 2");
            Scanner item2 = new Scanner(System.in);   
            int shippingitem2 = item2.nextInt();
            
            System.out.println("Enter the shipping cost of item 3");
            Scanner item3 = new Scanner(System.in);   
            int shppingitem3 = item3.nextInt();
            
            System.out.println("total shipping cost of items = " + (shippingitem1+shippingitem2+shppingitem3) );
            
            item1.close();
            item2.close();
            item3.close();
            
      }

}



