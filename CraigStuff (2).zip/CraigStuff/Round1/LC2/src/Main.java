import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		System.out.println("Enter the Name.");
		Scanner scanName = new Scanner(System.in);
		String name = scanName.next();
		scanName.close();
		System.out.println("Hello " + name + " get access to the unique shipping.");
	}

}
