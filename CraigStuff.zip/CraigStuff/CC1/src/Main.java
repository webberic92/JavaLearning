import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DecimalFormat;

public class Main {

	public static void main(String[] args) throws Exception {
		
		System.out.println("Enter Agent Details.");
		
		//String
		System.out.println("Enter NAME.");
		BufferedReader brName = new BufferedReader (new InputStreamReader(System.in));
		String name = brName.readLine();
		
		
		//String
		System.out.println("Enter INVOICE ID .");
		BufferedReader brInvoice = new BufferedReader (new InputStreamReader(System.in));
		String id = brInvoice.readLine();


		//Double
		System.out.println("Enter Amount");
		BufferedReader brAmount = new BufferedReader (new InputStreamReader(System.in));
		
		//Starts as a String but then converts into Double and applies Decimal Format.
		String amount =  brAmount.readLine();
		double dubAmount = Double.parseDouble(amount);
		DecimalFormat df = new DecimalFormat("#.00");
		
	
		
		System.out.println("Agent Details are..");
		System.out.println("Name= " +name);
		System.out.println("Invoice Id= " +id);
		System.out.println("Amount= " +df.format(dubAmount));

		
		
		brName.close();
		brInvoice.close();
		brAmount.close();
		
				
		
	}

}
