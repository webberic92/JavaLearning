import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		System.out.println("Enter User Details");
		
		//INT
		System.out.println("Enter ID.");
		Scanner userID = new Scanner(System.in);
		int id = userID.nextInt();
		
		
		//String
		System.out.println("Enter Name.");
		Scanner userName = new Scanner(System.in);
		String name = userName.next();

		//String
		System.out.println("Enter User Name.");
		Scanner userUserName = new Scanner(System.in);
		String screenName = userUserName.next();

		//String
		System.out.println("Enter Password.");
		Scanner userPassword = new Scanner(System.in);
		String password = userPassword.next();
		
		//String
		System.out.println("Enter Mobile Number.");
		Scanner mobileNumber = new Scanner(System.in);
		String phone = mobileNumber.next();
		
		//Double
		System.out.println("Enter Rating.");
		Scanner userRating = new Scanner(System.in);
		Double rating = userRating.nextDouble();
		
		System.out.println("User Details are..");
		System.out.println("ID= " +id);
		System.out.println("NAME= " +name);
		System.out.println("USERNAME= " +screenName);
		System.out.println("MOBILENUMBER= " +phone);
		System.out.println("RATING= " +rating);
		
		userID.close();
		userName.close();
		userUserName.close();
		userPassword.close();
		mobileNumber.close();
		userRating.close();



		
		
	}

}
