import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DecimalFormat;

public class Main {

	public static void main(String[] args) throws Exception {
		
		System.out.println("Enter Agent Details.");
		
		//String
		System.out.println("Enter NAME.");
		BufferedReader brName = new BufferedReader (new InputStreamReader(System.in));
		String name = brName.readLine();
		
		
		//String
		System.out.println("Enter ID NUMBER.");
		BufferedReader brID = new BufferedReader (new InputStreamReader(System.in));
		String id = brID.readLine();

		//String
		System.out.println("Enter ACCOUNT NUMBER.");
		BufferedReader brAccount = new BufferedReader (new InputStreamReader(System.in));
		String account = brAccount.readLine();


		//Double
		System.out.println("Enter Credit Limit.");
		BufferedReader brCredit = new BufferedReader (new InputStreamReader(System.in));
		
		//Starts as a String but then converts into Double and applies Decimal Format.
		String credit =  brCredit.readLine();
		double creditNum = Double.parseDouble(credit);
		DecimalFormat df = new DecimalFormat("#.00");
		
	
		
		System.out.println("Agent Details are..");
		System.out.println("Name= " +name);
		System.out.println("Id= " +id);
		System.out.println("Account= " +account);
		System.out.println("CreditLimit= " +df.format(creditNum));

		
		
		brName.close();
		brID.close();
		brAccount.close();
		brCredit.close();
		
				
		
	}

}
